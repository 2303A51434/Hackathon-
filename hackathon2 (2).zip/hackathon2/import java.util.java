import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    
    static class ResearchProject {
        private String title;
        private String researcher;
        private String status;

        public ResearchProject(String title, String researcher, String status) {
            this.title = title;
            this.researcher = researcher;
            this.status = status;
        }

        public String toString() {
            return "Title: " + title + ", Researcher: " + researcher + ", Status: " + status;
        }
    }

    static class Startup {
        private String name;
        private String founder;
        private String stage;

        public Startup(String name, String founder, String stage) {
            this.name = name;
            this.founder = founder;
            this.stage = stage;
        }

        public String toString() {
            return "Startup: " + name + ", Founder: " + founder + ", Stage: " + stage;
        }
    }

    static class Patent {
        private String title;
        private String applicant;
        private String status;

        public Patent(String title, String applicant, String status) {
            this.title = title;
            this.applicant = applicant;
            this.status = status;
        }

        public String toString() {
            return "Patent: " + title + ", Applicant: " + applicant + ", Status: " + status;
        }
    }

    // --- Central Repository ---
    static class DataRepository {
        public List<ResearchProject> researchProjects = new ArrayList<>();
        public List<Startup> startups = new ArrayList<>();
        public List<Patent> patents = new ArrayList<>();

        public void addResearchProject(ResearchProject p) {
            researchProjects.add(p);
        }

        public void addStartup(Startup s) {
            startups.add(s);
        }

        public void addPatent(Patent p) {
            patents.add(p);
        }

        public void displayAll() {
            System.out.println("\n--- Research Projects ---");
            researchProjects.forEach(System.out::println);

            System.out.println("\n--- Startups ---");
            startups.forEach(System.out::println);

            System.out.println("\n--- Patents ---");
            patents.forEach(System.out::println);
        }
    }

    // --- Main Application ---
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DataRepository repo = new DataRepository();

        while (true) {
            System.out.println("\n1. Add Research Project");
            System.out.println("2. Add Startup");
            System.out.println("3. Add Patent");
            System.out.println("4. View All Entries");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // clear buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter Researcher: ");
                    String researcher = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();
                    repo.addResearchProject(new ResearchProject(title, researcher, status));
                    break;

                case 2:
                    System.out.print("Enter Startup Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Founder: ");
                    String founder = sc.nextLine();
                    System.out.print("Enter Stage: ");
                    String stage = sc.nextLine();
                    repo.addStartup(new Startup(name, founder, stage));
                    break;

                case 3:
                    System.out.print("Enter Patent Title: ");
                    String pTitle = sc.nextLine();
                    System.out.print("Enter Applicant: ");
                    String applicant = sc.nextLine();
                    System.out.print("Enter Patent Status: ");
                    String pStatus = sc.nextLine();
                    repo.addPatent(new Patent(pTitle, applicant, pStatus));
                    break;

                case 4:
                    repo.displayAll();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}